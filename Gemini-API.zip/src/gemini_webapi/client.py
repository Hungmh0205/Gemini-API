import asyncio
import builtins
import codecs
import contextlib
import io
import random
import secrets
import time
import uuid
from asyncio import Task
from collections.abc import AsyncGenerator, Iterator, Sequence
from datetime import UTC, datetime
from pathlib import Path
from textwrap import shorten
from typing import Any, Optional

import orjson as json
from curl_cffi.requests import AsyncSession, BrowserTypeLiteral, Cookies, Response
from curl_cffi.requests.exceptions import ReadTimeout

from .components import ChatMixin, GemMixin, ResearchMixin
from .constants import (
    ARTIFACTS_RE,
    BROWSER_TYPE,
    CARD_CONTENT_RE,
    DEFAULT_LANGUAGE,
    DEFAULT_METADATA,
    DEFAULT_PUSH_ID,
    GEM_FLAG_INDEX,
    GEMINI_ADVANCED_QUOTA_PAYLOAD,
    GEMINI_FLASH_QUOTA_PAYLOAD,
    GRPC,
    MODEL_HEADER_KEY,
    MODEL_PREFIX_RE,
    STREAMING_FLAG_INDEX,
    TEMPORARY_CHAT_FLAG_INDEX,
    AccountStatus,
    Endpoint,
    ErrorCode,
    Field,
    Headers,
    Model,
    format_http_version,
    warn_deprecated_model,
)
from .exceptions import (
    APIError,
    AuthError,
    GeminiError,
    ModelInvalidError,
    TemporarilyBlockedError,
    TimeoutError,
    UsageLimitExceededError,
)
from .types import (
    AvailableModel,
    Candidate,
    ChatHistory,
    ChatInfo,
    Citation,
    DeepResearchDocument,
    DeepResearchPlan,
    Gem,
    GeneratedImage,
    GeneratedMedia,
    GeneratedVideo,
    ModelOutput,
    RPCData,
    WebImage,
)
from .utils import (
    StreamingFrameParser,
    clear_cookies_cache,
    extract_citations,
    extract_deep_research_document,
    extract_deep_research_plan,
    extract_json_from_response,
    get_access_token,
    get_delta_by_fp_len,
    get_nested_value,
    get_rich_content_field,
    logger,
    parse_file_name,
    rotate_1psidts,
    running,
    save_cookies,
    upload_file,
)


class GeminiClient(ChatMixin, GemMixin, ResearchMixin):
    """Async requests client interface for gemini.google.com.

    `secure_1psid` must be provided unless the optional dependency `browser-cookie3` is installed, and
    you have logged in to google.com in your local browser.

    Parameters
    ----------
    secure_1psid: `str`, optional
        __Secure-1PSID cookie value.
    secure_1psidts: `str`, optional
        __Secure-1PSIDTS cookie value, some Google accounts don't require this value, provide only if it's in the cookie list.
    proxy: `str`, optional
        Proxy URL.
    kwargs: `dict`, optional
        Additional arguments which will be passed to the http client.
        Refer to `curl_cffi.requests.AsyncSession` for more information.

    Raises
    ------
    `ValueError`
        If `browser-cookie3` is installed but cookies for google.com are not found in your local browser storage.

    """

    __slots__ = [
        "_abuse_status",
        "_cookie_source",
        "_cookies",
        "_gems",  # From GemMixin
        "_lock",
        "_model_registry",
        "_quotas",
        "_recent_chats",  # From ChatMixin
        "_reqid",
        "_running",
        "_sessionid",
        "_usage_info",
        "access_token",
        "account_status",
        "activity_task",
        "auto_close",
        "auto_refresh",
        "build_label",
        "client",
        "close_delay",
        "close_task",
        "impersonate",
        "kwargs",
        "language",
        "last_activity_time",
        "proxy",
        "push_id",
        "refresh_interval",
        "refresh_task",
        "session_id",
        "timeout",
        "verbose",
        "watchdog_timeout",
    ]

    def __init__(
        self,
        secure_1psid: str | None = None,
        secure_1psidts: str | None = None,
        proxy: str | None = None,
        **kwargs,
    ):
        super().__init__()
        self.proxy = proxy
        self.client: AsyncSession | None = None
        self.access_token: str | None = None
        self.build_label: str | None = None
        self.session_id: str | None = None
        self.language: str = DEFAULT_LANGUAGE
        self.push_id: str = DEFAULT_PUSH_ID
        self.account_status: AccountStatus = AccountStatus.AVAILABLE
        self.timeout: float = 450
        self.auto_close: bool = False
        self.close_delay: float = 450
        self.close_task: Task | None = None
        self.auto_refresh: bool = True
        self.refresh_interval: float = 600
        self.refresh_task: Task | None = None
        self.watchdog_timeout: float = 120  # seconds before declaring a zombie stream
        self.impersonate: BrowserTypeLiteral = BROWSER_TYPE
        self.verbose: bool = False
        self._abuse_status: dict | None = None
        self.last_activity_time: float = 0
        self.activity_task: Task | None = None
        self._running: bool = False
        self._cookies = Cookies()
        self._cookie_source: str = ""
        self._sessionid = str(uuid.uuid4()).upper()
        self._reqid: int = random.randint(10000, 99999)
        self._model_registry: dict[str, AvailableModel] = {}
        self._lock = asyncio.Lock()
        self._quotas: dict[str, dict] = {}
        self._usage_info: dict[str, Any] = {}
        self.kwargs = kwargs

        if secure_1psid:
            self._cookies.set("__Secure-1PSID", secure_1psid, domain=".google.com", secure=True)
            if secure_1psidts:
                self._cookies.set(
                    "__Secure-1PSIDTS", secure_1psidts, domain=".google.com", secure=True
                )

    @property
    def quotas(self) -> dict[str, dict]:
        """Get the current account quotas/limits (obsolete, use `usage_info` for the newer compute-usage based metrics).

        Each bucket reports whichever usage window is currently binding - the one closest
        to or past its limit - rather than a window of its own, and the window pairs in the
        request payload do not influence which one comes back. That window is resolved
        against `usage_info` and recorded under `"window"`, where every window is listed
        separately.
        """
        return self._quotas

    @property
    def usage_info(self) -> dict[str, Any]:
        """Get the current compute-usage metrics from Gemini usage info."""
        return self._usage_info

    @property
    def abuse_status(self) -> dict | None:
        """Get the current account abuse status and flags."""
        return self._abuse_status

    @property
    def _live_client(self) -> AsyncSession:
        """Returns the underlying http session, which only exists while the client is running.

        Raises
        ------
        `gemini_webapi.APIError`
            If the client is not initialized.

        """
        if self.client is None:
            raise APIError(
                "Invalid request: client is not initialized. Call `GeminiClient.init()` first."
            )

        return self.client

    @property
    def cookies(self) -> Cookies:
        """Returns the cookies used for the current session."""
        return self.client.cookies if self.client else self._cookies

    @cookies.setter
    def cookies(self, value: Cookies | dict):
        """Set the cookies to use for the session."""
        if isinstance(value, Cookies):
            self._cookies.update(value)
        elif isinstance(value, dict):
            for k, v in value.items():
                self._cookies.set(k, v, domain=".google.com", secure=True)

        if self.client:
            self.client.cookies.update(self._cookies)

    async def init(
        self,
        timeout: float = 450,
        auto_close: bool = False,
        close_delay: float = 450,
        auto_refresh: bool = True,
        refresh_interval: float = 600,
        watchdog_timeout: float = 120,
        impersonate: BrowserTypeLiteral = BROWSER_TYPE,
        verbose: bool = False,
    ) -> None:
        """Get SNlM0e value as access token. Without this token posting will fail with 400 bad request.

        Parameters
        ----------
        timeout: `float`, optional
            Request timeout of the client in seconds. Used to limit the max waiting time when sending a request.
        auto_close: `bool`, optional
            If `True`, the client will close connections and clear resource usage after a certain period
            of inactivity. Useful for always-on services.
        close_delay: `float`, optional
            Time to wait before auto-closing the client in seconds. Effective only if `auto_close` is `True`.
        auto_refresh: `bool`, optional
            If `True`, will schedule tasks to automatically refresh cookies and tokens and maintain connection.
        refresh_interval: `float`, optional
            Time interval for background cookie and access token refresh in seconds.
            Effective only if `auto_refresh` is `True`.
        watchdog_timeout: `float`, optional
            Timeout in seconds for shadow retry watchdog. If no data receives from stream but connection is active,
            client will retry automatically after this duration.
        impersonate: `BrowserTypeLiteral`, optional
            Allow to customize client, default to `BROWSER_TYPE`.
            Firefox usually gets a "Stream suspended" error.
        verbose: `bool`, optional
            If `True`, will print more infomation in logs.

        """
        async with self._lock:
            if self._running:
                return

            try:
                self.verbose = verbose
                self.watchdog_timeout = watchdog_timeout
                self.impersonate = impersonate
                init_session = await get_access_token(
                    base_cookies=self.cookies,
                    proxy=self.proxy,
                    verbose=self.verbose,
                    impersonate=impersonate,
                    verify=self.kwargs.get("verify", True),
                )

                init_session.client.timeout = timeout
                self.client = init_session.client
                self._cookie_source = init_session.cookie_source
                self._cookies.update(self.client.cookies)
                self.access_token = init_session.access_token
                self.build_label = init_session.build_label
                self.session_id = init_session.session_id
                self.language = init_session.language or DEFAULT_LANGUAGE
                self.push_id = init_session.push_id or DEFAULT_PUSH_ID
                self._running = True
                self._sessionid = str(uuid.uuid4()).upper()
                self._reqid = random.randint(10000, 99999)

                self.timeout = timeout
                self.auto_close = auto_close
                self.close_delay = close_delay
                if self.auto_close:
                    await self.reset_close_task()

                self.auto_refresh = auto_refresh
                self.refresh_interval = refresh_interval

                await self._init_rpc()

                if self.refresh_task:
                    self.refresh_task.cancel()
                    self.refresh_task = None

                if self.auto_refresh and self._check_account_status():
                    self.refresh_task = asyncio.create_task(self.start_auto_refresh())

                if self.activity_task:
                    self.activity_task.cancel()
                    self.activity_task = None

                if self.auto_refresh and self._check_account_status():
                    self.activity_task = asyncio.create_task(self.start_activity_watchdog())

                logger.success("Gemini client initialized successfully.")
            except Exception:
                self._running = False
                await self.close()
                raise

    async def close(self, delay: float = 0) -> None:
        """Close the client and save cookies.

        Parameters
        ----------
        delay: `float`, optional
            Time to wait before closing the client in seconds.

        """
        if delay:
            await asyncio.sleep(delay)
            logger.debug(
                f"Auto-close option "
                f"[{'enabled' if self.auto_close else 'disabled'}] "
                f"triggered client closing."
            )

        was_running = self._running
        self._running = False

        if self.close_task:
            self.close_task.cancel()
            self.close_task = None

        if self.refresh_task:
            self.refresh_task.cancel()
            self.refresh_task = None

        if self.activity_task:
            self.activity_task.cancel()
            self.activity_task = None

        if self.client:
            self._cookies.update(self.client.cookies)
            await self.client.close()
            self.client = None

        # Only save cookies if the client was running and successfully initialized.
        # When init() fails (e.g. network/DNS error), self._cookies only contains uninitialized
        # or initial base cookies, which must never overwrite existing valid cache files.
        if not was_running:
            return

        # Cached cookies are tried ahead of the ones the caller supplies, so caching an
        # unauthenticated session would restore an entry just cleared as stale, or create
        # the very entry that shadows real credentials on the next run.
        if self.account_status == AccountStatus.UNAUTHENTICATED:
            logger.debug("Skipping cookie cache write: the session is not authenticated.")
            return

        try:
            save_cookies(self._cookies, self.verbose)
        except OSError as e:
            logger.warning(f"Failed to save cookies to cache file: {e}")

    async def reset_close_task(self) -> None:
        """Reset the timer for closing the client when a new request is made."""
        if self.close_task:
            self.close_task.cancel()
            self.close_task = None

        self.close_task = asyncio.create_task(self.close(self.close_delay))

    async def start_activity_watchdog(self) -> None:
        """Start the background task to ensure periodic activity calls."""
        while self._running:
            interval = random.uniform(60, 120)  # Random interval between 60 and 120 seconds
            while self._running:
                elapsed = time.time() - self.last_activity_time
                remaining = interval - elapsed
                if remaining <= 0:
                    break
                await asyncio.sleep(min(remaining, 10))

            if not self._running:
                break

            if not self._check_account_status():
                logger.warning(
                    f"Stopping the activity watchdog. Account status: {self.account_status.name} - {self.account_status.description}"
                )
                self.activity_task = None
                break

            try:
                logger.debug(
                    f"Heartbeat triggered. Time since last activity: {int(time.time() - self.last_activity_time)}s"
                )
                await self._sync_activity()
            except asyncio.CancelledError:
                raise
            except Exception as e:
                logger.warning(f"Unexpected error in activity watchdog: {e}")

    async def start_auto_refresh(self) -> None:
        """Start the background task to automatically refresh cookies with random jitter.

        Adds ±15 seconds of random jitter to the refresh interval to prevent synchronized
        background tasks. The final interval is clamped to a minimum of 60 seconds.
        """
        self.refresh_interval = max(self.refresh_interval, 60)

        while self._running:
            jitter = random.uniform(-15, 15)
            await asyncio.sleep(max(60, self.refresh_interval + jitter))

            if not self._running:
                break

            if not self._check_account_status():
                logger.warning(
                    f"Stopping the auto-refresh cookies. Account status: {self.account_status.name} - {self.account_status.description}"
                )
                self.refresh_task = None
                break

            try:
                async with self._lock:
                    # Refresh all cookies in the background to keep the session alive.
                    new_1psidts = await rotate_1psidts(self._live_client, self.verbose)

                    if not new_1psidts:
                        logger.warning(
                            "Rotation response did not contain a __Secure-1PSIDTS. "
                            "The current cookies may have been invalidated by the server. "
                            "Retrying in next interval."
                        )
            except asyncio.CancelledError:
                raise
            except AuthError:
                logger.warning(
                    "AuthError: Failed to refresh cookies. "
                    "The current cookies may have been invalidated by the server. "
                    "Retrying in next interval."
                )
            except Exception as e:
                logger.warning(
                    f"Unexpected error while refreshing cookies: {e}. Retrying in next interval."
                )

    def _parse_rpc_results(self, response_text: str, target_id: str) -> Iterator[Any]:
        """Extract parts from a batch response and yield only those matching the target RPC ID."""
        try:
            response_json = extract_json_from_response(response_text)
            for part in response_json:
                if get_nested_value(part, [1]) != target_id:
                    continue

                # Check for server-side rejection (e.g., code 7 for permission denied)
                reject_code = get_nested_value(part, [5, 0])
                if reject_code == 7:
                    self.account_status = AccountStatus.UNAUTHENTICATED
                    logger.warning(
                        f"RPC request {target_id} failed: Permission denied or unauthenticated."
                    )
                    break

                part_body_str = get_nested_value(part, [2])
                if not part_body_str:
                    continue

                try:
                    yield json.loads(part_body_str)
                except (json.JSONDecodeError, TypeError):
                    continue
        except Exception as e:
            if self.verbose:
                logger.debug(f"Failed to extract JSON from response: {e}")

    async def _init_rpc(self) -> None:
        """Send initial RPC calls to set up the session."""
        await self._fetch_user_status()
        await self._fetch_preferences()
        await self._sync_activity()
        await self._fetch_recent_chats()
        # Usage info first: it lists every window, which is what identifies the single
        # binding window the quota RPC reports back.
        await self._fetch_usage_info()
        await self._fetch_quota()
        await self._fetch_extra_quota()
        await self._fetch_abuse_status()

    async def _fetch_user_status(self) -> None:
        """Fetch user status and parse available models dynamically from the Gemini API.

        Builds :class:`AvailableModel` instances from the RPC response so that
        model headers are always up-to-date without hardcoded values.
        """
        response = await self._batch_execute(
            [
                RPCData(
                    rpcid=GRPC.GET_USER_STATUS,
                    payload="[]",
                )
            ]
        )

        for part_body in self._parse_rpc_results(response.text, GRPC.GET_USER_STATUS):
            status_code = get_nested_value(part_body, [14])
            self.account_status = AccountStatus.from_status_code(status_code)

            if self.account_status == AccountStatus.AVAILABLE:
                if self.verbose:
                    logger.info(
                        f"Account status: {self.account_status.name} - {self.account_status.description}"
                    )
            else:
                logger.warning(
                    f"Account status: {self.account_status.name} - {self.account_status.description}"
                )
                if (
                    self.account_status == AccountStatus.UNAUTHENTICATED
                    and self._cookie_source.startswith("Cache")
                ):
                    # A stale cache entry would shadow working credentials on every later
                    # run, since cached cookies are tried first and are accepted as soon as
                    # they yield a token - which an unauthenticated session also does. Only
                    # the cache is dropped, and only when it produced this session: it also
                    # holds rotated cookies, often the freshest credentials the client has.
                    logger.debug(
                        "Cached cookies produced an unauthenticated session; clearing them "
                        "so the next attempt can fall through to the supplied credentials."
                    )
                    clear_cookies_cache(self.cookies, self.verbose)
                if self.account_status in [
                    AccountStatus.LOCATION_REJECTED,
                    AccountStatus.ACCOUNT_REJECTED,
                    AccountStatus.ACCESS_TEMPORARILY_UNAVAILABLE,
                    AccountStatus.ACCOUNT_REJECTED_BY_GUARDIAN,
                    AccountStatus.GUARDIAN_APPROVAL_REQUIRED,
                ]:
                    logger.warning(
                        f"Hard block detected ({self.account_status.name}). Skipping model discovery."
                    )
                    continue

            models_list = get_nested_value(part_body, [15])
            if isinstance(models_list, list):
                tier_flags = get_nested_value(part_body, [16], [])
                tier_flags = tier_flags if isinstance(tier_flags, list) else []
                capability_flags = get_nested_value(part_body, [17], [])
                capability_flags = capability_flags if isinstance(capability_flags, list) else []
                capacity, capacity_field = AvailableModel.compute_capacity(
                    tier_flags, capability_flags
                )

                unauth = self.account_status == AccountStatus.UNAUTHENTICATED
                parsed_any = False
                for model_data in models_list:
                    if isinstance(model_data, list) and (
                        model := AvailableModel.from_rpc(
                            model_data,
                            capacity=capacity,
                            capacity_field=capacity_field,
                            # Guest sessions may only use the default model, listed first
                            unavailable=unauth and parsed_any,
                        )
                    ):
                        self._model_registry[model.model_id] = model
                        parsed_any = True

                return

    async def _fetch_quota(
        self,
        flash: bool = False,
        advanced: bool = False,
    ) -> None:
        """Fetch quota limits for Gemini models.
        Supports semantic selection of quota tiers.

        Parameters
        ----------
        flash: `bool`, optional
            If True, fetches limits for Gemini Flash and Flash Lite models.
        advanced: `bool`, optional
            If True, fetches limits for Gemini Pro models and Extended Thinking level.

        """
        if not self._check_account_status():
            return

        if not any([flash, advanced]):
            flash = True
            advanced = True
        to_fetch: list[tuple[str, str]] = []
        if flash:
            to_fetch.append((GEMINI_FLASH_QUOTA_PAYLOAD, "Flash"))
        if advanced:
            to_fetch.append((GEMINI_ADVANCED_QUOTA_PAYLOAD, "Pro"))

        for payload_str, category in to_fetch:
            try:
                response = await self._batch_execute(
                    [
                        RPCData(
                            rpcid=GRPC.CHECK_GEMINI_QUOTA,
                            payload=payload_str,
                        )
                    ]
                )

                for part_body in self._parse_rpc_results(response.text, GRPC.CHECK_GEMINI_QUOTA):
                    quota_items = get_nested_value(part_body, [0])

                    if not isinstance(quota_items, list):
                        continue

                    for item in quota_items:
                        quota_id_list = get_nested_value(item, [0], [])
                        action_id = get_nested_value(item, [0, 1])
                        usage_level = get_nested_value(item, [2])
                        reset_ts = get_nested_value(item, [3, 0])
                        total = get_nested_value(item, [4])
                        remaining = get_nested_value(item, [5])

                        quota_id = "-".join(map(str, quota_id_list))

                        action_labels = {
                            4: "Gemini Pro",
                            11: "Gemini Flash",
                            15: "Gemini Flash Thinking",
                        }
                        label = action_labels.get(action_id, f"Gemini {category}")
                        display_target = f"{label} [{quota_id}]"

                        quota_data = {
                            "usage_percentage": usage_level,
                            "reset_time": reset_ts,
                            "total": total,
                            "remaining": remaining,
                            "action_id": action_id,
                            "label": display_target,
                            "window": self._resolve_usage_window(reset_ts),
                        }

                        self._quotas[quota_id] = quota_data

                        if isinstance(usage_level, (int, float)):
                            reset_str = ""
                            if reset_ts:
                                try:
                                    reset_dt = datetime.fromtimestamp(reset_ts, tz=UTC).astimezone()
                                    reset_str = (
                                        f" (Resets: {reset_dt.strftime('%Y-%m-%d %H:%M:%S %Z')})"
                                    )
                                except (ValueError, OSError, OverflowError):
                                    reset_str = f" (Resets at timestamp: {reset_ts})"

                            quota_display = (
                                "Unlimited"
                                if (total == 0 and remaining == 0)
                                else f"{remaining}/{total} credits remaining"
                            )
                            logger.info(
                                f"Account quota updated: {display_target} - {quota_display}{reset_str}"
                            )

                            if usage_percentage := usage_level:
                                if usage_percentage >= 100:
                                    logger.error(
                                        f"Account quota EXHAUSTED for {display_target}: {quota_display}.{reset_str}"
                                    )
                                elif usage_percentage >= 90:
                                    logger.warning(
                                        f"Account quota critical: Usage is at {usage_percentage:.1f}% for {display_target} ({quota_display}).{reset_str}"
                                    )
                                elif usage_percentage >= 75:
                                    logger.warning(
                                        f"Account quota warning: Usage is at {usage_percentage:.1f}% for {display_target} ({quota_display}).{reset_str}"
                                    )

            except Exception as e:
                logger.error(
                    f"Failed to fetch quota for payload {shorten(payload_str, width=60)}: {e}"
                )
                continue

    async def _fetch_abuse_status(self) -> None:
        """Check for account abuse markers and signals."""
        response = await self._batch_execute(
            [
                RPCData(
                    rpcid=GRPC.GET_ABUSE_STATUS,
                    payload="[]",
                )
            ]
        )

        for part_body in self._parse_rpc_results(response.text, GRPC.GET_ABUSE_STATUS):
            abuse_info = get_nested_value(part_body, [1])

            if not abuse_info:
                self._abuse_status = {
                    "is_clean": True,
                    "status_code": None,
                    "signal": None,
                }
                logger.info("Account abuse status: Clean (No flags detected).")
                continue

            raw_status = get_nested_value(abuse_info, [1])
            signal = get_nested_value(abuse_info, [3, 1])

            status_code = int(raw_status) // 1_000_000 if raw_status is not None else None

            self._abuse_status = {
                "is_clean": False,
                "status_code": status_code,
                "signal": signal,
            }

            logger.warning(
                f"Potential account restriction or abnormal status detected: {self._abuse_status}"
            )

    async def _fetch_extra_quota(self) -> None:
        """Check additional feature quotas and capability caps.

        Note: This method does not pre-verify account status with _check_account_status
        and relies on internal rejection code handling (e.g., code 7).
        """
        response = await self._batch_execute(
            [
                RPCData(
                    rpcid=GRPC.CHECK_QUOTA,
                    payload="[]",
                )
            ]
        )

        for part_body in self._parse_rpc_results(response.text, GRPC.CHECK_QUOTA):
            is_blocked = get_nested_value(part_body, [0])
            usage_level = get_nested_value(part_body, [1])
            reset_ts = get_nested_value(part_body, [2, 0])

            if "extra" not in self._quotas:
                self._quotas["extra"] = {}
            self._quotas["extra"]["default"] = {
                "is_blocked": is_blocked,
                "usage_percentage": usage_level * 100
                if isinstance(usage_level, (int, float))
                else None,
                "reset_time": reset_ts,
            }

            if is_blocked:
                reset_str = (
                    f" (Resets: {datetime.fromtimestamp(reset_ts).astimezone().strftime('%Y-%m-%d %H:%M:%S %Z')})"
                    if reset_ts
                    else ""
                )
                logger.error(f"Extra feature quota exceeded: Hard block detected.{reset_str}")
            elif isinstance(usage_level, (int, float)):
                usage_pc = usage_level * 100
                reset_str = (
                    f" (Resets: {datetime.fromtimestamp(reset_ts).astimezone().strftime('%Y-%m-%d %H:%M:%S %Z')})"
                    if reset_ts
                    else ""
                )
                if usage_pc >= 90:
                    logger.warning(
                        f"Extra feature quota critical: Usage is at {usage_pc:.1f}%.{reset_str}"
                    )
                elif usage_pc >= 75:
                    logger.warning(
                        f"Extra feature quota warning: Usage is at {usage_pc:.1f}%.{reset_str}"
                    )

            if self.verbose:
                logger.info(f"Extra quota check: Blocked={is_blocked}, UsageLevel={usage_level}")

    async def _fetch_usage_info(self) -> None:
        """Fetch compute-based usage limits shown in Gemini's usage limits window.

        The newer GetUsageInfo RPC is compute-based usage rather than request
        quota based. It returns the plan tier, the overage AI credits preference,
        and usage fractions for the current 5-hour and weekly windows. Each
        metric is exposed once at its top-level window key with remaining credits,
        the rounded percentage used by the web UI, and a formatted reset time.
        When the RPC includes an AI credit metric, its remaining credits are
        stored separately as ``ai_credits_remaining``.
        """
        if not self._check_account_status():
            return

        response = await self._batch_execute(
            [
                RPCData(
                    rpcid=GRPC.GET_USAGE_INFO,
                    payload="[]",
                )
            ],
            source_path="/usage",
        )

        tier_id = None
        use_overage_ai_credits = None
        usage_info: dict[str, Any] = {}
        tier_labels = {
            1: "FREE",
            2: "PRO",
            3: "ULTRA",
            4: "PLUS",
            6: "ULTRA",
        }
        metric_windows = {
            1: ("current_5h", "5h"),
            2: ("weekly", "weekly"),
        }

        for part_body in self._parse_rpc_results(response.text, GRPC.GET_USAGE_INFO):
            tier_id = get_nested_value(part_body, [0])
            usage_items = get_nested_value(part_body, [1], [])
            use_overage_ai_credits = get_nested_value(part_body, [2])

            usage_info = {
                "tier": {
                    "id": tier_id,
                    "label": tier_labels.get(tier_id),
                },
                "use_overage_ai_credits": use_overage_ai_credits,
                "current_5h": None,
                "weekly": None,
            }

            if not isinstance(usage_items, list):
                continue

            for item in usage_items:
                remaining = get_nested_value(item, [0])
                metric_type = get_nested_value(item, [2])
                usage_level = get_nested_value(item, [1])
                reset_ts = get_nested_value(item, [3, 0, 0])
                reset_at = None
                if reset_ts:
                    reset_at = datetime.fromtimestamp(reset_ts, tz=UTC).astimezone().isoformat()

                if metric_type == 3:
                    usage_info["ai_credits_remaining"] = remaining
                    continue

                metric_label, window = metric_windows.get(
                    metric_type, (f"type_{metric_type}", "unknown")
                )
                usage_percentage = (
                    round(usage_level * 100) if isinstance(usage_level, (int, float)) else None
                )
                metric_info = {
                    "type": metric_type,
                    "window": window,
                    "remaining_credits": remaining,
                    "usage_level": usage_level,
                    "usage_percentage": usage_percentage,
                    "reset_at": reset_at,
                }
                usage_info[metric_label] = metric_info

        self._usage_info = usage_info
        self._quotas["usage_info"] = usage_info

        if self.verbose and usage_info:
            logger.info(f"Usage info updated: {usage_info}")

    async def _fetch_preferences(self) -> None:
        """Fetch user preferences and data context flags."""
        await self._batch_execute(
            [
                RPCData(
                    rpcid=GRPC.READ_USER_PREFERENCES,
                    payload='[[["adaptive_device_responses_enabled","advanced_mode_theme_override_triggered","advanced_zs_upsell_dismissal_count","advanced_zs_upsell_last_dismissed","ai_transparency_notice_dismissed","audio_overview_discovery_dismissal_count","audio_overview_discovery_last_dismissed","bard_in_chrome_link_sharing_enabled","bard_sticky_mode_disabled_count","canvas_create_discovery_tooltip_seen_count","combined_files_button_tag_seen_count","indigo_banner_explicit_dismissal_count","indigo_banner_impression_count","indigo_banner_last_seen_sec","current_popup_id","deep_research_has_seen_file_upload_tooltip","deep_research_model_update_disclaimer_display_count","default_bot_id","disabled_discovery_card_feature_ids","disabled_model_discovery_tooltip_feature_ids","disabled_mode_disclaimers","disabled_new_model_badge_mode_ids","disabled_settings_discovery_tooltip_feature_ids","disablement_disclaimer_last_dismissed_sec","disable_advanced_beta_dialog","disable_advanced_beta_non_en_banner","disable_advanced_resubscribe_ui","disable_at_mentions_discovery_tooltip","disable_autorun_fact_check_u18","disable_bot_create_tips_card","disable_bot_docs_in_gems_disclaimer","disable_bot_onboarding_dialog","disable_bot_save_reminder_tips_card","disable_bot_send_prompt_tips_card","disable_bot_shared_in_drive_disclaimer","disable_bot_try_create_tips_card","disable_colab_tooltip","disable_collapsed_tool_menu_tooltip","disable_continue_discovery_tooltip","disable_debug_info_moved_tooltip_v2","disable_enterprise_mode_dialog","disable_export_python_tooltip","disable_extensions_discovery_dialog","disable_extension_one_time_badge","disable_fact_check_tooltip_v2","disable_free_file_upload_tips_card","disable_generated_image_download_dialog","disable_get_app_banner","disable_get_app_desktop_dialog","disable_googler_in_enterprise_mode","disable_human_review_disclosure","disable_ice_open_vega_editor_tooltip","disable_image_upload_tooltip","disable_legal_concern_tooltip","disable_llm_history_import_disclaimer","disable_location_popup","disable_memory_discovery","disable_memory_extraction_discovery","disable_new_conversation_dialog","disable_onboarding_experience","disable_personal_context_tooltip","disable_photos_upload_disclaimer","disable_power_up_intro_tooltip","disable_scheduled_actions_mobile_notification_snackbar","disable_storybook_listen_button_tooltip","disable_streaming_settings_tooltip","disable_take_control_disclaimer","disable_teens_only_english_language_dialog","disable_tier1_rebranding_tooltip","disable_try_advanced_mode_dialog","enable_advanced_beta_mode","enable_advanced_mode","enable_googler_in_enterprise_mode","enable_memory","enable_memory_extraction","enable_personal_context","enable_personal_context_gemini","enable_personal_context_gemini_using_photos","enable_personal_context_gemini_using_workspace","enable_personal_context_search","enable_personal_context_youtube","enable_token_streaming","enforce_default_to_fast_version","mayo_discovery_banner_dismissal_count","mayo_discovery_banner_last_dismissed_sec","gempix_discovery_banner_dismissal_count","gempix_discovery_banner_last_dismissed","get_app_banner_ack_count","get_app_banner_seen_count","get_app_mobile_dialog_ack_count","guided_learning_banner_dismissal_count","guided_learning_banner_last_dismissed","has_accepted_agent_mode_fre_disclaimer","has_received_streaming_response","has_seen_agent_mode_tooltip","has_seen_bespoke_tooltip","has_seen_deepthink_mustard_tooltip","has_seen_deepthink_v2_tooltip","has_seen_deep_think_tooltip","has_seen_first_youtube_video_disclaimer","has_seen_ggo_tooltip","has_seen_image_grams_discovery_banner","has_seen_image_preview_in_input_area_tooltip","has_seen_kallo_discovery_banner","has_seen_kallo_tooltip","has_seen_model_picker_in_input_area_tooltip","has_seen_model_tooltip_in_input_area_for_gempix","has_seen_redo_with_gempix2_tooltip","has_seen_veograms_discovery_banner","has_seen_video_generation_discovery_banner","is_imported_chats_panel_open_by_default","jumpstart_onboarding_dismissal_count","last_dismissed_deep_research_implicit_invite","last_dismissed_discovery_feature_implicit_invites","last_dismissed_immersives_canvas_implicit_invite","last_dismissed_immersive_share_disclaimer_sec","last_dismissed_strike_timestamp_sec","last_dismissed_zs_student_aip_banner_sec","last_get_app_banner_ack_timestamp_sec","last_get_app_mobile_dialog_ack_timestamp_sec","last_human_review_disclosure_ack","last_selected_mode_id_in_embedded","last_selected_mode_id_on_web","last_two_up_activation_timestamp_sec","last_winter_olympics_interaction_timestamp_sec","memory_extracted_greeting_name","mini_gemini_tos_closed","mode_switcher_soft_badge_disabled_ids","mode_switcher_soft_badge_seen_count","personalization_first_party_onboarding_cross_surface_clicked","personalization_first_party_onboarding_cross_surface_seen_count","personalization_one_p_discovery_card_seen_count","personalization_one_p_discovery_last_consented","personalization_zero_state_card_last_interacted","personalization_zero_state_card_seen_count","popup_zs_visits_cooldown","require_reconsent_setting_for_personalization_banner_seen_count","show_debug_info","side_nav_open_by_default","student_verification_dismissal_count","student_verification_last_dismissed","task_viewer_cc_banner_dismissed_count","task_viewer_cc_banner_dismissed_time_sec","tool_menu_new_badge_disabled_ids","tool_menu_new_badge_impression_counts","tool_menu_soft_badge_disabled_ids","tool_menu_soft_badge_impression_counts","upload_disclaimer_last_consent_time_sec","viewed_student_aip_upsell_campaign_ids","voice_language","voice_name","web_and_app_activity_enabled","wellbeing_nudge_notice_last_dismissed_sec","zs_student_aip_banner_dismissal_count"]]]',
                )
            ]
        )

    async def _sync_activity(self) -> None:
        """Sync user activity status and maintain session heartbeat."""
        self.last_activity_time = time.time()

        if not self._check_account_status():
            return

        rpcs = [
            RPCData(
                rpcid=GRPC.READ_USER_PREFERENCES,
                payload='[[["bard_activity_enabled"]]]',
            )
        ]
        try:
            await self._batch_execute(rpcs)
        except asyncio.CancelledError:
            raise
        except Exception:
            # Mạng/SSL chập chờn thoáng qua (BoringSSL SSL_ERROR_SYSCALL...):
            # thử lại 1 lần sau 5s để khỏi spam WARNING ở activity watchdog.
            await asyncio.sleep(5)
            try:
                await self._batch_execute(rpcs)
            except asyncio.CancelledError:
                raise

    def list_models(self) -> list[AvailableModel] | None:
        """List all available models for the current account.
        Model list is only available after GeminiClient.init() is successfully called.

        Returns
        -------
        `list[gemini_webapi.types.AvailableModel] | None`
            List of models with their name and description.
            Returns `None` if the client holds no session cache.

        """
        return list(self._model_registry.values()) if self._model_registry else None

    def resolve_model(self, name: str) -> AvailableModel:
        """Resolve a model name, alias, display name or hex id against this client's registry.

        Parameters
        ----------
        name: `str`
            Model name, alias, display name or `model_id` to look up.

        Returns
        -------
        `gemini_webapi.types.AvailableModel`
            The matching model this account discovered at initialization.

        Raises
        ------
        `ValueError`
            If the name matches no discovered model.

        """
        return self._resolve_model_by_name(name)

    def _resolve_model_by_name(self, name: str) -> AvailableModel:
        """Resolve a model name against the models this account discovered."""
        if name in self._model_registry:
            return self._model_registry[name]

        target = name.lower().strip()

        # 1st priority: Exact match on model_id, model_name, or display_name
        for m in self._model_registry.values():
            if (
                m.model_name.lower() == target
                or m.display_name.lower() == target
                or m.model_id.lower() == target
            ):
                return m

        # 2nd priority: Alias match
        for m in self._model_registry.values():
            if target in m.aliases:
                return m

        # 3rd priority: Version-agnostic normalized match against dynamic registry
        norm_target = MODEL_PREFIX_RE.sub("", target).replace("_", "-")
        for m in self._model_registry.values():
            norm_model = MODEL_PREFIX_RE.sub("", m.model_name.lower()).replace("_", "-")
            if norm_target == norm_model or norm_target in norm_model.split("-"):
                return m

        available_names = [m.model_name for m in self._model_registry.values()]
        raise ValueError(
            f"Unknown model name: '{name}'. Available registered models: "
            f"{', '.join(available_names) if available_names else 'None (call client.init() first)'}"
        )

    def _resolve_enum_model(self, model: Model) -> AvailableModel | None:
        """Upgrade a deprecated :class:`Model` member to this account's equivalent.

        Returns `None` for `UNSPECIFIED`, and for a member whose hardcoded id the account does
        not offer - both mean "no model header", letting Google pick its default rather than
        sending an id that may no longer exist.
        """
        if model is Model.UNSPECIFIED:
            return None

        if header_value := model.model_header.get(MODEL_HEADER_KEY, ""):
            with contextlib.suppress(json.JSONDecodeError):
                parsed = json.loads(header_value)
                model_id = get_nested_value(parsed, [4], "")
                if model_id and model_id in self._model_registry:
                    return self._model_registry[model_id]

        logger.warning(
            f"{model} has no counterpart in this account's models; falling back to the default "
            "model rather than sending a hardcoded header Google may no longer accept."
        )
        return None

    def _resolve_usage_window(self, reset_ts: int | float | None) -> str | None:
        """Name the usage window a quota bucket is reporting, by its reset time.

        The quota RPC returns whichever window is currently binding without saying which
        one that is, so the window is identified by matching its reset timestamp against
        the windows in `usage_info`. Returns `None` when no window matches, rather than
        guessing - the caller still has the raw reset time either way.
        """
        if not reset_ts:
            return None

        for window in ("current_5h", "weekly"):
            metric = self._usage_info.get(window)
            if not isinstance(metric, dict) or not (reset_at := metric.get("reset_at")):
                continue

            with contextlib.suppress(ValueError, TypeError):
                # Same instant either side; a minute absorbs the two responses being
                # generated at slightly different times
                if abs(datetime.fromisoformat(reset_at).timestamp() - reset_ts) <= 60:
                    return window

        return None

    def _quota_reset_hint(self, quota_id: str | None = None) -> str:
        """Describe when a quota recovers, from the reset timestamps already cached.

        Parameters
        ----------
        quota_id: `str`, optional
            Restrict the hint to one bucket. Omit it to report whichever known quota or
            usage window resets soonest.

        Returns
        -------
        `str`
            A sentence that can be appended to any message, empty when no future reset is
            known, so callers never have to branch on it.

        """
        now = datetime.now(tz=UTC)
        candidates: list[tuple[datetime, str]] = []

        for key, quota in self._quotas.items():
            if key in ("extra", "usage_info") or not isinstance(quota, dict):
                continue
            if quota_id is not None and key != quota_id:
                continue
            if reset_ts := quota.get("reset_time"):
                with contextlib.suppress(ValueError, OSError, OverflowError, TypeError):
                    candidates.append(
                        (
                            datetime.fromtimestamp(reset_ts, tz=UTC),
                            str(quota.get("label") or key),
                        )
                    )

        # Usage windows apply to the account as a whole, so they answer only the general
        # question of what recovers next, never one about a single bucket.
        if quota_id is None:
            for window in ("current_5h", "weekly"):
                metric = self._usage_info.get(window)
                if isinstance(metric, dict) and (reset_at := metric.get("reset_at")):
                    with contextlib.suppress(ValueError, TypeError):
                        candidates.append((datetime.fromisoformat(reset_at), window))

        upcoming = sorted((dt, label) for dt, label in candidates if dt > now)
        if not upcoming:
            return ""

        reset_at, label = upcoming[0]
        remaining = reset_at - now
        hours, seconds = divmod(int(remaining.total_seconds()), 3600)
        local = reset_at.astimezone()
        return (
            f" Quota for {label} resets at {local.strftime('%Y-%m-%d %H:%M:%S %Z')} "
            f"(in {hours}h {seconds // 60}m)."
        )

    def _check_account_status(self, raise_error: bool = False) -> bool:
        """Check if the account is available for higher-level operations.

        Parameters
        ----------
        raise_error: `bool`, optional
            If `True`, raises `GeminiError` if the account is not available (defaults to `False`).
            If `False`, returns a boolean indicating availability.

        Returns
        -------
        `bool`
            `True` if account is AVAILABLE, `False` otherwise.

        Raises
        ------
        GeminiError
            If `raise_error` is `True` and account status is not AccountStatus.AVAILABLE.

        """
        is_available = self.account_status == AccountStatus.AVAILABLE
        if not is_available and raise_error:
            raise GeminiError(
                f"Permission denied. Account status: {self.account_status.name} - {self.account_status.description}"
            )
        return is_available

    async def generate_content(
        self,
        prompt: str,
        files: list[str | Path | bytes | io.BytesIO] | None = None,
        model: AvailableModel | Model | str | dict | None = None,
        gem: Gem | str | None = None,
        chat: Optional["ChatSession"] = None,
        temporary: bool = False,
        deep_research: bool = False,
        extended_thinking: bool = False,
        **kwargs,
    ) -> ModelOutput:
        """Generates contents with prompt.

        Parameters
        ----------
        prompt: `str`
            Text prompt provided by user.
        files: `list[str | Path | bytes | io.BytesIO]`, optional
            List of file paths or byte streams to be attached.
        model: `AvailableModel | str | dict`, optional
            Specify the model to use for generation. Pass a model name, alias or id string, or an
            `gemini_webapi.types.AvailableModel` from `list_models()`. Omit it to let Google use
            the account's default model. The `gemini_webapi.constants.Model` enum is deprecated
            and still accepted, with a warning.
        gem: `Gem | str`, optional
            Specify a gem to use as system prompt for the chat session.
            Pass either a `gemini_webapi.types.Gem` object or a gem id string.
        chat: `ChatSession`, optional
            Chat data to retrieve conversation history.
            If None, will automatically generate a new chat id when sending post request.
        temporary: `bool`, optional
            If set to `True`, the ongoing conversation will not show up in Gemini history.
        deep_research: `bool`, optional
            If set to `True`, will enable deep research mode and start creating a deep research plan.
        extended_thinking: `bool`, optional
            If set to `True`, will enable extended thinking mode, default to standard.
        kwargs: `dict`, optional
            Additional arguments which will be passed to the post request.
            Refer to `curl_cffi.requests.AsyncSession.request` for more information.

        Returns
        -------
        :class:`ModelOutput`
            Output data from gemini.google.com.

        Raises
        ------
        `AssertionError`
            If prompt is empty.
        `gemini_webapi.TimeoutError`
            If request timed out.
        `gemini_webapi.GeminiError`
            If no reply candidate found in response.
        `gemini_webapi.APIError`
            - If request failed with status code other than 200.
            - If response structure is invalid and failed to parse.

        """
        if self.auto_close:
            await self.reset_close_task()

        if any([files, gem, deep_research]):
            self._check_account_status(raise_error=True)

        file_data = None
        if files:
            await self._sync_activity()

            uploaded_urls = await asyncio.gather(
                *(
                    upload_file(
                        file,
                        client=self._live_client,
                        push_id=self.push_id,
                        verbose=self.verbose,
                    )
                    for file in files
                )
            )
            file_data = [
                [[url], parse_file_name(file)]
                for url, file in zip(uploaded_urls, files, strict=True)
            ]

        try:
            await self._sync_activity()

            session_state = {
                "last_texts": {},
                "last_thoughts": {},
            }
            output = None
            async for chunk in self._generate(
                prompt=prompt,
                req_file_data=file_data,
                model=model,
                gem=gem,
                chat=chat,
                temporary=temporary,
                session_state=session_state,
                deep_research=deep_research,
                extended_thinking=extended_thinking,
                **kwargs,
            ):
                output = chunk

            if output is None:
                raise GeminiError("Failed to generate contents. No output data found in response.")

            if isinstance(chat, ChatSession):
                output.metadata = chat.metadata
                chat.last_output = output

            return output

        finally:
            if files:
                for file in files:
                    if isinstance(file, io.BytesIO):
                        file.close()

    async def generate_content_stream(
        self,
        prompt: str,
        files: list[str | Path | bytes | io.BytesIO] | None = None,
        model: AvailableModel | Model | str | dict | None = None,
        gem: Gem | str | None = None,
        chat: Optional["ChatSession"] = None,
        temporary: bool = False,
        deep_research: bool = False,
        extended_thinking: bool = False,
        **kwargs,
    ) -> AsyncGenerator[ModelOutput, None]:
        """Generates contents with prompt in streaming mode.

        This method sends a request to Gemini and yields partial responses as they arrive.
        It automatically calculates the text delta (new characters) to provide a smooth
        streaming experience. It parses length-prefixed response frames incrementally
        so large unfinished frames are not rescanned after every network chunk. It also
        continuously updates chat metadata and candidate IDs.

        Parameters
        ----------
        prompt: `str`
            Text prompt provided by user.
        files: `list[str | Path | bytes | io.BytesIO]`, optional
            List of file paths or byte streams to be attached.
        model: `AvailableModel | str | dict`, optional
            Specify the model to use for generation, by name or as a model from `list_models()`.
            Omit it to let Google use the account's default model.
        gem: `Gem | str`, optional
            Specify a gem to use as system prompt for the chat session.
        chat: `ChatSession`, optional
            Chat data to retrieve conversation history.
        temporary: `bool`, optional
            If set to `True`, the ongoing conversation will not show up in Gemini history.
        deep_research: `bool`, optional
            If set to `True`, will enable deep research mode and start creating a deep research plan.
        extended_thinking: `bool`, optional
            If set to `True`, will enable extended thinking mode, default to standard.
        kwargs: `dict`, optional
            Additional arguments passed to `curl_cffi.requests.AsyncSession.stream`.

        Yields
        ------
        :class:`ModelOutput`
            Partial output data. The `text_delta` attribute contains only the NEW characters
            received since the last yield.

        Raises
        ------
        `gemini_webapi.APIError`
            If the request fails or response structure is invalid.
        `gemini_webapi.TimeoutError`
            If the stream request times out.

        """
        if self.auto_close:
            await self.reset_close_task()

        if any([files, gem, deep_research]):
            self._check_account_status(raise_error=True)

        file_data = None
        if files:
            await self._sync_activity()

            uploaded_urls = await asyncio.gather(
                *(
                    upload_file(
                        file,
                        client=self._live_client,
                        push_id=self.push_id,
                        verbose=self.verbose,
                    )
                    for file in files
                )
            )
            file_data = [
                [[url], parse_file_name(file)]
                for url, file in zip(uploaded_urls, files, strict=True)
            ]

        try:
            await self._sync_activity()

            session_state = {
                "last_texts": {},
                "last_thoughts": {},
            }
            output = None
            async for output in self._generate(
                prompt=prompt,
                req_file_data=file_data,
                model=model,
                gem=gem,
                chat=chat,
                temporary=temporary,
                session_state=session_state,
                deep_research=deep_research,
                extended_thinking=extended_thinking,
                **kwargs,
            ):
                yield output

            if output and isinstance(chat, ChatSession):
                output.metadata = chat.metadata
                chat.last_output = output

        finally:
            if files:
                for file in files:
                    if isinstance(file, io.BytesIO):
                        file.close()

    @running(retry=5)
    async def _generate(
        self,
        prompt: str,
        req_file_data: list[Any] | None = None,
        model: AvailableModel | Model | str | dict | None = None,
        gem: Gem | str | None = None,
        chat: Optional["ChatSession"] = None,
        temporary: bool = False,
        session_state: dict[str, Any] | None = None,
        deep_research: bool = False,
        extended_thinking: bool = False,
        **kwargs,
    ) -> AsyncGenerator[ModelOutput, None]:
        """Internal method which actually sends content generation requests.

        When a model header is present, its JSPB model selector is extended with
        the current client session id before the streaming request is sent, and
        the model number from that selector is mirrored into the request body. The
        streaming response parser keeps partial frame state internally to avoid
        repeated scans of large cumulative response frames.
        """
        assert prompt, "Prompt cannot be empty."

        # Resolved down to one of two things: a model this account offers, or None for "let
        # Google pick", so nothing below has to know which form the caller passed.
        selected: AvailableModel | None
        if model is None or isinstance(model, AvailableModel):
            selected = model
        elif isinstance(model, str):
            selected = self._resolve_model_by_name(model)
        elif isinstance(model, dict):
            selected = AvailableModel.from_dict(model)
        elif isinstance(model, Model):
            warn_deprecated_model(f"Passing {model} to generate_content()")
            selected = self._resolve_enum_model(model)
        else:
            raise TypeError(
                f"'model' must be an `AvailableModel`, string, dictionary or None; "
                f"got `{type(model).__name__}`"
            )

        model_label = selected.model_name if selected else "the default model"

        if selected is not None and not selected.is_available:
            raise GeminiError(
                f"{model_label} is not available for use. Account status: {self.account_status.name} - {self.account_status.description}"
            )

        _reqid = self._reqid
        self._reqid += 100000

        gem_id = gem.id if isinstance(gem, Gem) else gem

        chat_backup: dict[str, Any] | None = None
        if chat:
            chat_backup = {
                "metadata": (
                    chat.metadata if getattr(chat, "metadata", None) else DEFAULT_METADATA
                ),
                "cid": getattr(chat, "cid", ""),
                "rid": getattr(chat, "rid", ""),
                "rcid": getattr(chat, "rcid", ""),
            }

        if session_state is None:
            session_state = {
                "last_texts": {},
                "last_thoughts": {},
            }

        # Bound once outside the retry loop, they are the same dicts on every attempt
        last_texts: dict[str, str] = session_state["last_texts"]
        last_thoughts: dict[str, str] = session_state["last_thoughts"]

        has_generated_text = False
        sleep_time = 10

        message_content = [
            prompt,
            0,
            None,
            req_file_data,
            None,
            None,
            0,
        ]

        params: dict[str, Any] = {"hl": self.language, "_reqid": _reqid, "rt": "c"}
        if self.build_label:
            params["bl"] = self.build_label
        if self.session_id:
            params["f.sid"] = self.session_id

        while True:
            try:
                inner_req_list: list[Any] = [None] * 81
                inner_req_list[0] = message_content
                inner_req_list[1] = [self.language]
                inner_req_list[2] = chat.metadata if chat else DEFAULT_METADATA
                if deep_research:
                    inner_req_list[3] = f"!{secrets.token_urlsafe(2600)}"
                    inner_req_list[4] = uuid.uuid4().hex
                inner_req_list[6] = [1]
                inner_req_list[STREAMING_FLAG_INDEX] = 1
                inner_req_list[10] = 1
                inner_req_list[11] = 0
                inner_req_list[17] = [[0]]
                inner_req_list[18] = 0
                if gem_id:
                    inner_req_list[GEM_FLAG_INDEX] = gem_id
                inner_req_list[27] = 1
                inner_req_list[30] = [4]
                inner_req_list[41] = [1]
                if temporary:
                    inner_req_list[TEMPORARY_CHAT_FLAG_INDEX] = 1
                if deep_research:
                    inner_req_list[49] = 1
                inner_req_list[53] = 0
                if deep_research:
                    inner_req_list[54] = [[[[[1]]]]]
                    inner_req_list[55] = [[1]]
                inner_req_list[61] = []
                inner_req_list[68] = 1
                inner_req_list[79] = 1
                inner_req_list[80] = 2 if extended_thinking else 1

                uuid_val = str(uuid.uuid4()).upper()

                inner_req_list[59] = uuid_val

                model_headers = selected.model_header.copy() if selected else {}
                if MODEL_HEADER_KEY in model_headers:
                    model_header = json.loads(model_headers[MODEL_HEADER_KEY])
                    model_number = model_header[-1] if model_header else None
                    if isinstance(model_number, int):
                        inner_req_list[79] = model_number
                    model_header.append(2 if extended_thinking else 1)
                    model_header.append(self._sessionid)
                    model_headers[MODEL_HEADER_KEY] = json.dumps(model_header).decode("utf-8")

                request_headers = {
                    **Headers.GEMINI.value,
                    **model_headers,
                    "x-goog-ext-525005358-jspb": f'["{uuid_val}",1]',
                    **Headers.SAME_DOMAIN.value,
                }

                request_data = {
                    "at": self.access_token or "",  # Guest sessions have no SNlM0e token
                    "f.req": json.dumps(
                        [
                            None,
                            json.dumps(inner_req_list).decode("utf-8"),
                        ]
                    ).decode("utf-8"),
                }

                async with self._live_client.stream(
                    "POST",
                    Endpoint.GENERATE,
                    params=params,
                    headers=request_headers,
                    data=request_data,
                    **kwargs,
                ) as response:
                    if self.verbose:
                        logger.debug(
                            f"HTTP Request: POST {Endpoint.GENERATE} [{response.status_code}] (HTTP/{format_http_version(response.http_version)})"
                        )
                    if response.status_code != 200:
                        raise APIError(
                            f"Failed to generate contents. Status: {response.status_code}"
                        )

                    stream_parser = StreamingFrameParser()
                    _raw_response_parts = []
                    decoder = codecs.getincrementaldecoder("utf-8")(errors="replace")

                    last_progress_time: float = time.time()

                    is_thinking = False
                    is_queueing = False
                    has_candidates = False
                    is_completed = False  # Check if this conversation turn has been fully answered.
                    is_final_chunk = False  # Check if this turn is saved to history and marked complete or still pending (e.g., video generation).
                    cid = chat.cid if chat else ""
                    rid = chat.rid if chat else ""

                    async def _process_parts(
                        parts: list[Any],
                    ) -> AsyncGenerator[ModelOutput, None]:
                        nonlocal \
                            is_thinking, \
                            is_queueing, \
                            has_candidates, \
                            is_completed, \
                            is_final_chunk, \
                            cid, \
                            rid
                        for part in parts:
                            # Check for fatal error codes
                            error_code = get_nested_value(part, [5, 2, 0, 1, 0])
                            if error_code:
                                match error_code:
                                    case ErrorCode.USAGE_LIMIT_EXCEEDED:
                                        raise UsageLimitExceededError(
                                            f"Usage limit exceeded for model '{model_label}'.{self._quota_reset_hint()} "
                                            "You can switch to a different model (e.g., Gemini Flash), "
                                            "or check your account limits on gemini.google.com."
                                        )
                                    case ErrorCode.MODEL_INCONSISTENT:
                                        raise ModelInvalidError(
                                            "The specified model is inconsistent with the conversation history. "
                                            "Please ensure you are using the same 'model' parameter throughout the entire ChatSession."
                                        )
                                    case ErrorCode.MODEL_HEADER_INVALID:
                                        raise ModelInvalidError(
                                            f"The model '{model_label}' is currently unavailable or the request structure is outdated. "
                                            "Please update 'gemini_webapi' to the latest version or report this on GitHub if the problem persists."
                                        )
                                    case ErrorCode.IP_TEMPORARILY_BLOCKED:
                                        raise TemporarilyBlockedError(
                                            "Your IP address has been temporarily flagged or blocked by Google. "
                                            "Please try using a proxy, a different network, or wait for a while before retrying."
                                        )
                                    case ErrorCode.TEMPORARY_ERROR_1013:
                                        raise APIError(
                                            "Gemini encountered a temporary error (1013). Retrying..."
                                        )
                                    case _:
                                        raise APIError(
                                            f"Failed to generate contents (stream). Unknown API error code: {error_code}. "
                                            "This might be a temporary Google service issue."
                                        )

                            # Check for queueing status
                            status = get_nested_value(part, [5])
                            if isinstance(status, list) and status and not is_thinking:
                                is_queueing = True
                                if not has_candidates:
                                    logger.debug("Model is in a waiting state (queueing)...")

                            inner_json_str = get_nested_value(part, [2])
                            if inner_json_str:
                                try:
                                    part_json = json.loads(inner_json_str)
                                    m_data = get_nested_value(part_json, [1])
                                    if m_data:
                                        _new_cid = get_nested_value(m_data, [0])
                                        _new_rid = get_nested_value(m_data, [1])
                                        if _new_cid:
                                            cid = _new_cid
                                        if _new_rid:
                                            rid = _new_rid

                                        if isinstance(chat, ChatSession):
                                            chat.metadata = m_data

                                    # Check for busy analyzing data
                                    tool_name = get_nested_value(part_json, [6, 1, 0])
                                    if tool_name == "data_analysis_tool":
                                        is_thinking = True
                                        is_queueing = False
                                        if not has_candidates:
                                            logger.debug("Model is active (thinking/analyzing)...")

                                    context_str = get_nested_value(part_json, [25])
                                    if isinstance(context_str, str):
                                        is_final_chunk = True
                                        is_thinking = False
                                        is_queueing = False
                                        if isinstance(chat, ChatSession):
                                            chat.metadata = [None] * 9 + [context_str]

                                    timestamp_data = get_nested_value(part_json, [27, 0, 0, 3])
                                    timestamp = time.time()
                                    if (
                                        isinstance(timestamp_data, list)
                                        and len(timestamp_data) >= 2
                                    ):
                                        seconds = timestamp_data[0]
                                        nanos = timestamp_data[1]
                                        timestamp = float(seconds) + (float(nanos) / 1e9)

                                    candidates_list = get_nested_value(part_json, [4], [])
                                    if candidates_list:
                                        output_candidates = []
                                        for i, candidate_data in enumerate(candidates_list):
                                            rcid = get_nested_value(candidate_data, [0])
                                            if not rcid:
                                                continue
                                            if isinstance(chat, ChatSession):
                                                chat.rcid = rcid

                                            (
                                                text,
                                                thoughts,
                                                web_images,
                                                generated_images,
                                                generated_videos,
                                                generated_media,
                                                citations,
                                            ) = self._parse_candidate(
                                                candidate_data, cid, rid, rcid
                                            )

                                            deep_research_plan = None
                                            deep_research_document = None
                                            if deep_research:
                                                plan_data = extract_deep_research_plan(
                                                    candidate_data,
                                                    fallback_text=text,
                                                )

                                                if plan_data:
                                                    deep_research_plan = DeepResearchPlan(
                                                        **plan_data,
                                                        cid=getattr(chat, "cid", None),
                                                    )

                                                # The report is an inline document, not text
                                                if doc_data := extract_deep_research_document(
                                                    candidate_data
                                                ):
                                                    deep_research_document = DeepResearchDocument(
                                                        **doc_data
                                                    )

                                            # Check if this frame represents the complete state of the message
                                            indicator = get_nested_value(candidate_data, [8, 0])
                                            is_completed = indicator == 2

                                            # Save this conversation turn to recent chats whenever it is stored in history.
                                            if is_final_chunk and (
                                                cid and isinstance(self._recent_chats, list)
                                            ):
                                                chat_title = f"Chat({cid})"
                                                is_pinned = False
                                                for c in self._recent_chats:
                                                    if c.cid == cid:
                                                        chat_title = c.title
                                                        is_pinned = c.is_pinned
                                                        break

                                                expected_idx = (
                                                    0
                                                    if is_pinned
                                                    else sum(
                                                        bool(c.cid != cid and c.is_pinned)
                                                        for c in self._recent_chats
                                                    )
                                                )

                                                if not (
                                                    len(self._recent_chats) > expected_idx
                                                    and self._recent_chats[expected_idx].cid == cid
                                                    and self._recent_chats[expected_idx].title
                                                    == chat_title
                                                    and self._recent_chats[expected_idx].timestamp
                                                    == timestamp
                                                ):
                                                    self._recent_chats = [
                                                        c
                                                        for c in self._recent_chats
                                                        if c.cid != cid
                                                    ]
                                                    self._recent_chats.insert(
                                                        expected_idx,
                                                        ChatInfo(
                                                            cid=cid,
                                                            title=chat_title,
                                                            is_pinned=is_pinned,
                                                            timestamp=timestamp,
                                                        ),
                                                    )

                                            last_sent_text = last_texts.get(rcid) or last_texts.get(
                                                f"idx_{i}", ""
                                            )
                                            text_delta, new_full_text = get_delta_by_fp_len(
                                                text,
                                                last_sent_text,
                                                is_final=is_completed or indicator is None,
                                            )
                                            last_sent_thought = last_thoughts.get(
                                                rcid
                                            ) or last_thoughts.get(f"idx_{i}", "")
                                            if thoughts:
                                                thoughts_delta, new_full_thought = (
                                                    get_delta_by_fp_len(
                                                        thoughts,
                                                        last_sent_thought,
                                                        is_final=is_completed or indicator is None,
                                                    )
                                                )
                                            else:
                                                thoughts_delta = ""
                                                new_full_thought = ""

                                            if (
                                                text_delta
                                                or thoughts_delta
                                                or web_images
                                                or generated_images
                                                or generated_videos
                                                or generated_media
                                                or deep_research_plan
                                            ):
                                                has_candidates = True

                                            # Update state with the provider's cleaned state to handle drift
                                            last_texts[rcid] = last_texts[f"idx_{i}"] = (
                                                new_full_text
                                            )

                                            last_thoughts[rcid] = last_thoughts[f"idx_{i}"] = (
                                                new_full_thought
                                            )

                                            output_candidates.append(
                                                Candidate(
                                                    rcid=rcid,
                                                    text=text,
                                                    text_delta=text_delta,
                                                    thoughts=thoughts or None,
                                                    thoughts_delta=thoughts_delta,
                                                    web_images=web_images,
                                                    generated_images=generated_images,
                                                    generated_videos=generated_videos,
                                                    generated_media=generated_media,
                                                    citations=citations,
                                                    deep_research_plan=deep_research_plan,
                                                    deep_research_document=deep_research_document,
                                                )
                                            )

                                        if output_candidates:
                                            is_thinking = False
                                            is_queueing = False
                                            yield ModelOutput(
                                                metadata=[cid, rid],
                                                candidates=output_candidates,
                                            )
                                except json.JSONDecodeError:
                                    continue

                    chunk_iterator = response.aiter_content().__aiter__()
                    while True:
                        stall_threshold = (
                            self.timeout
                            if (is_thinking or is_queueing)
                            else min(self.timeout, self.watchdog_timeout)
                        )
                        try:
                            chunk = await asyncio.wait_for(
                                chunk_iterator.__anext__(), timeout=stall_threshold + 5
                            )
                        except StopAsyncIteration:
                            break
                        except builtins.TimeoutError:
                            logger.debug(
                                f"[Watchdog] Socket idle for {stall_threshold + 5}s. Refreshing connection..."
                            )
                            break

                        decoded_chunk = decoder.decode(chunk, final=False)
                        if self.verbose:
                            _raw_response_parts.append(decoded_chunk)
                        parsed_parts = stream_parser.feed(decoded_chunk)

                        got_update = False
                        async for out in _process_parts(parsed_parts):
                            has_generated_text = True
                            yield out
                            got_update = True

                        if got_update:
                            last_progress_time = time.time()
                        else:
                            stall_threshold = (
                                self.timeout
                                if (is_thinking or is_queueing)
                                else min(self.timeout, self.watchdog_timeout)
                            )
                            if (time.time() - last_progress_time) > stall_threshold:
                                if is_thinking:
                                    logger.debug(
                                        f"[Watchdog] Model is taking its time thinking ({int(time.time() - last_progress_time)}s). Reconnecting to poll..."
                                    )
                                    break
                                else:
                                    logger.debug(
                                        f"[Watchdog] Connection idle for {stall_threshold}s (queueing={is_queueing}). "
                                        "Attempting recovery..."
                                    )
                                    break

                    final_decoded = decoder.decode(b"", final=True)
                    if self.verbose:
                        _raw_response_parts.append(final_decoded)
                    parsed_parts = stream_parser.feed(final_decoded)
                    parsed_parts.extend(stream_parser.flush())
                    async for out in _process_parts(parsed_parts):
                        has_generated_text = True
                        yield out

                    if not is_completed or is_thinking or is_queueing:
                        # A known cid means the context was saved, but reading it back needs
                        # an account: a guest session has no history, so `read_chat` would
                        # refuse and surface the dropped stream as a "Permission denied"
                        # GeminiError - misleading, and not retryable. Guests fall through
                        # to the retryable branch below instead.
                        if cid and self._check_account_status():
                            logger.debug(
                                f"Stream incomplete. Checking conversation history for {cid}..."
                            )

                            # `is_final_chunk` is the strong signal that a turn was
                            # persisted, but not a necessary one: a capability refusal (e.g.
                            # video generation on an ineligible plan) ends the stream with a
                            # complete answer already in the conversation and no marker, and
                            # refusing to recover there made `@running(retry=5)` re-send the
                            # prompt six times for an answer that was already there. So
                            # recover on any known cid, on a short leash without the marker
                            # so a genuine abort still fails fast.
                            recovery_deadline = (
                                self.timeout
                                if is_final_chunk
                                else min(self.timeout, self.watchdog_timeout)
                            )

                            poll_start_time = time.time()

                            while True:
                                if (time.time() - poll_start_time) > recovery_deadline:
                                    logger.warning(
                                        f"[Recovery] Polling for {cid} timed out after {recovery_deadline}s."
                                    )
                                    if has_generated_text:
                                        raise GeminiError(
                                            "The connection to Gemini was lost while generating the response, and recovery timed out. "
                                            "Please try sending your prompt again."
                                        )
                                    else:
                                        raise APIError(
                                            "read_chat polling timed out waiting for the model to finish. "
                                            "The original request may have been silently aborted by Google."
                                        )
                                await self._sync_activity()
                                recovered_history = await self.read_chat(cid)
                                if (
                                    recovered_history
                                    and recovered_history.turns
                                    and recovered_history.turns[0].role == "model"
                                ):
                                    recovered = recovered_history.turns[0].model_output
                                    if (
                                        recovered
                                        and recovered.candidates
                                        and (
                                            recovered.text
                                            or recovered.thoughts
                                            or recovered.images
                                            or recovered.videos
                                            or recovered.media
                                        )
                                    ):
                                        rec_rcid = recovered.rcid
                                        prev_rcid = chat_backup["rcid"] if chat_backup else ""
                                        current_expected_rcid = (
                                            getattr(chat, "rcid", "") if chat else ""
                                        )

                                        is_new_turn = rec_rcid != prev_rcid

                                        if is_new_turn:
                                            logger.debug(
                                                f"[Recovery] Successfully recovered response for CID: {cid} (RCID: {rec_rcid})"
                                            )
                                            if chat:
                                                recovered.metadata = chat.metadata
                                                chat.rcid = rec_rcid

                                            # `read_chat` builds candidates whose delta is
                                            # the whole answer, which would replay text the
                                            # stream consumer already printed - so rebase
                                            # each delta on what was sent. `generate_content`
                                            # is unaffected: it reads `.text` and ignores
                                            # deltas entirely.
                                            for i, candidate in enumerate(recovered.candidates):
                                                sent_text = last_texts.get(
                                                    candidate.rcid
                                                ) or last_texts.get(f"idx_{i}", "")
                                                sent_thoughts = last_thoughts.get(
                                                    candidate.rcid
                                                ) or last_thoughts.get(f"idx_{i}", "")

                                                candidate.text_delta, _ = get_delta_by_fp_len(
                                                    candidate.text, sent_text, is_final=True
                                                )
                                                candidate.thoughts_delta, _ = get_delta_by_fp_len(
                                                    candidate.thoughts or "",
                                                    sent_thoughts,
                                                    is_final=True,
                                                )

                                            yield recovered
                                            break
                                        else:
                                            logger.debug(
                                                f"[Recovery] Recovered turn is not the target turn (target: {current_expected_rcid or 'NEW'}, got {rec_rcid}). Waiting..."
                                            )

                                logger.debug(
                                    f"[Recovery] Response not ready, waiting {sleep_time}s..."
                                )
                                await asyncio.sleep(sleep_time)
                            break
                        elif deep_research and cid:
                            # Confirming a research plan legitimately ends the stream without
                            # completing the turn: the task was accepted and now runs
                            # server-side. Retrying here re-submits the research.
                            logger.debug(
                                f"Deep research accepted for {cid}; the task now runs "
                                "server-side. Not retrying the request."
                            )
                        else:
                            reason = (
                                "This session cannot read history, so the turn cannot be recovered"
                                if cid
                                else "No CID found to recover"
                            )
                            logger.debug(
                                f"Stream suspended (completed={is_completed}, final_chunk={is_final_chunk}, thinking={is_thinking}, queueing={is_queueing}). "
                                f"{reason}. (Request ID: {_reqid})"
                            )
                            # Close so the retry is a real refresh: `@running` re-runs
                            # `init()` only when the client is stopped, and `init()` is what
                            # picks a new backend, opening a new session and regenerating
                            # the session id, `f.sid` and `_reqid` that decide routing. The
                            # watchdog and the recovery timeout already close; a stream that
                            # simply ends does not, which re-sent the prompt six times over
                            # the same connection to the backend that just refused it.
                            await self.close()
                            raise APIError(
                                "The original request may have been silently aborted by Google."
                            )

                    if self.verbose:
                        _raw_response = "".join(_raw_response_parts)
                        debug_parser = StreamingFrameParser()
                        _parsed_full = debug_parser.feed(_raw_response)
                        _parsed_full.extend(debug_parser.flush())
                        logger.debug(
                            f"Full raw response received (parsed into {len(_parsed_full)} parts)"
                        )

                break

            except ReadTimeout:
                raise TimeoutError(
                    "The request timed out while waiting for Gemini to respond. This often happens with very long prompts "
                    "or complex file analysis. Try increasing the 'timeout' value when initializing GeminiClient."
                ) from None
            except (UsageLimitExceededError, GeminiError, APIError):
                if not has_generated_text and chat and chat_backup:
                    chat.metadata = chat_backup["metadata"]
                    chat.cid = chat_backup["cid"]
                    chat.rid = chat_backup["rid"]
                    chat.rcid = chat_backup["rcid"]
                raise
            except Exception as e:
                if not has_generated_text and chat and chat_backup:
                    chat.metadata = chat_backup["metadata"]
                    chat.cid = chat_backup["cid"]
                    chat.rid = chat_backup["rid"]
                    chat.rcid = chat_backup["rcid"]
                logger.debug(
                    "Stream parsing interrupted. Attempting to recover conversation context..."
                )
                raise APIError(
                    f"Failed to parse response body from Google ({type(e).__name__}: {e!r}). This might be a temporary API change or invalid data."
                ) from e

        # Refresh usage info after generation to update remaining credits and usage level
        await self._fetch_usage_info()

    def _parse_candidate(
        self, candidate_data: list[Any], cid: str, rid: str, rcid: str
    ) -> tuple[
        str,
        str,
        list[WebImage],
        list[GeneratedImage],
        list[GeneratedVideo],
        list[GeneratedMedia],
        list[Citation],
    ]:
        """Parses individual candidate data from the Gemini response.

        Parameters
        ----------
        candidate_data: `list[Any]`
            The raw candidate list from the API response.
        cid: `str`
            Chat ID.
        rid: `str`
            Reply ID.
        rcid: `str`
            Reply candidate ID.

        Returns
        -------
        `tuple[str, str, list[WebImage], list[GeneratedImage], list[GeneratedVideo], list[GeneratedMedia], list[Citation]]`
            By order, the returned tuple contains:
                - text: The main response text.
                - thoughts: The model's reasoning or internal thoughts.
                - web_images: List of images found on the web.
                - generated_images: List of images generated by the model.
                - generated_videos: List of videos generated by the model.
                - generated_media: List of media (music/audio) generated by the model.
                - citations: Web sources resolving the `[cite: N]` markers in the text.

        """
        text = get_nested_value(candidate_data, [1, 0], "")
        if CARD_CONTENT_RE.match(text):
            text = get_nested_value(candidate_data, [22, 0]) or text

        # Cleanup googleusercontent artifacts
        text = ARTIFACTS_RE.sub("", text)

        thoughts = get_nested_value(candidate_data, [37, 0, 0]) or ""

        # Image handling
        web_images = []
        for img_idx, web_img_data in enumerate(
            get_rich_content_field(candidate_data, Field.WEB_IMAGES, [])
        ):
            url = get_nested_value(web_img_data, [0, 0, 0])
            if url:
                web_images.append(
                    WebImage(
                        url=url,
                        title=f"[Image {img_idx + 1}]",
                        alt=get_nested_value(web_img_data, [0, 4], ""),
                        proxy=self.proxy,
                        client=self.client,
                    )
                )

        # The positional slot and the sparse key "8" are the same field 7, not the separate
        # "plain" and "image to image" sources a previous concatenation implied, so only one
        # of the two is ever populated.
        generated_images = []
        for img_idx, gen_img_data in enumerate(
            get_nested_value(
                get_rich_content_field(candidate_data, Field.GENERATED_IMAGES), [0], []
            )
        ):
            url = get_nested_value(gen_img_data, [0, 3, 3])
            if url:
                image_id = (
                    get_nested_value(gen_img_data, [1, 0])
                    or f"http://googleusercontent.com/image_generation_content/{img_idx}"
                )

                generated_images.append(
                    GeneratedImage(
                        url=url,
                        title=f"[Generated Image {img_idx}]",
                        alt=get_nested_value(gen_img_data, [0, 3, 2], ""),
                        proxy=self.proxy,
                        client=self.client,
                        client_ref=self,
                        cid=cid,
                        rid=rid,
                        rcid=rcid,
                        image_id=image_id,
                    )
                )

        # Video handling
        generated_videos = []
        video_info = get_nested_value(
            get_rich_content_field(candidate_data, Field.VIDEO), [0, 0, 0], []
        )
        if video_info:
            urls = get_nested_value(video_info, [0, 7], [])
            if len(urls) >= 2:
                generated_videos.append(
                    GeneratedVideo(
                        url=urls[1],
                        thumbnail=urls[0],
                        cid=cid,
                        rid=rid,
                        rcid=rcid,
                        client_ref=self,
                        proxy=self.proxy,
                    )
                )

        # Media (Music) handling
        generated_media = []
        media_data = get_rich_content_field(candidate_data, Field.MEDIA, [])
        if media_data:
            mp3_url = ""
            mp3_thumb = ""
            mp3_list = get_nested_value(media_data, [0, 1, 7], [])
            if len(mp3_list) >= 2:
                mp3_thumb = mp3_list[0]
                mp3_url = mp3_list[1]

            mp4_url = ""
            mp4_thumb = ""
            mp4_list = get_nested_value(media_data, [1, 1, 7], [])
            if len(mp4_list) >= 2:
                mp4_thumb = mp4_list[0]
                mp4_url = mp4_list[1]

            if mp3_url or mp4_url:
                generated_media.append(
                    GeneratedMedia(
                        url=mp4_url,
                        thumbnail=mp4_thumb,
                        mp3_url=mp3_url,
                        mp3_thumbnail=mp3_thumb,
                        cid=cid,
                        rid=rid,
                        rcid=rcid,
                        client_ref=self,
                        proxy=self.proxy,
                    )
                )

        # An ordinary turn can carry `[cite: N]` markers too, not just a research report,
        # with the sources published separately as field 43. It happens irregularly - most
        # turns publish no field 43 at all - so an empty list here is the normal case.
        citations = [
            Citation(**source)
            for source in extract_citations(get_rich_content_field(candidate_data, Field.CITATIONS))
        ]

        return (
            text,
            thoughts,
            web_images,
            generated_images,
            generated_videos,
            generated_media,
            citations,
        )

    async def _get_full_size_image(
        self, cid: str, rid: str, rcid: str, image_id: str
    ) -> str | None:
        """Get the full size URL of an image."""
        try:
            payload = [
                [
                    [None, None, None, [None, None, None, None, None, ""]],
                    [image_id, 0],
                    None,
                    [19, ""],
                    None,
                    None,
                    None,
                    None,
                    None,
                    "",
                ],
                [rid, rcid, cid, None, ""],
                1,
                0,
                1,
            ]

            response = await self._batch_execute(
                [
                    RPCData(
                        rpcid=GRPC.DOWNLOAD_GENERATED_IMAGE,
                        payload=json.dumps(payload).decode("utf-8"),
                    ),
                ]
            )

            response_data = extract_json_from_response(response.text)
            return get_nested_value(json.loads(get_nested_value(response_data, [0, 2], "[]")), [0])
        except Exception:
            logger.debug("_get_full_size_image Could not retrieve full size URL via RPC.")
            return None

    @running(retry=2)
    async def _batch_execute(
        self,
        payloads: list[RPCData],
        source_path: str = "/app",
        close_on_error: bool = True,
        **kwargs,
    ) -> Response:
        """Execute a batch of requests to Gemini API.

        The batch execution model header is parsed as JSPB data, extended with
        the current client session id as its trailing value, and serialized back
        into the header string before it is sent.

        Parameters
        ----------
        payloads: `list[RPCData]`
            List of `gemini_webapi.types.RPCData` objects to be executed.
        kwargs: `dict`, optional
            Additional arguments which will be passed to the post request.
            Refer to `curl_cffi.requests.AsyncSession.request` for more information.

        Returns
        -------
        :class:`curl_cffi.requests.Response`
            Response object containing the result of the batch execution.

        """
        _reqid = self._reqid
        self._reqid += 100000

        try:
            params: dict[str, Any] = {
                "rpcids": ",".join([p.rpcid for p in payloads]),
                "hl": self.language,
                "_reqid": _reqid,
                "rt": "c",
                "source-path": source_path,
            }
            if self.build_label:
                params["bl"] = self.build_label
            if self.session_id:
                params["f.sid"] = self.session_id

            batch_exec_headers = Headers.BATCH_EXEC.value.copy()
            batch_exec_header = json.loads(batch_exec_headers[MODEL_HEADER_KEY])
            batch_exec_header.append(self._sessionid)
            batch_exec_headers[MODEL_HEADER_KEY] = json.dumps(batch_exec_header).decode("utf-8")

            request_headers = {
                **Headers.GEMINI.value,
                **batch_exec_headers,
                **Headers.SAME_DOMAIN.value,
            }

            response = await self._live_client.post(
                Endpoint.BATCH_EXEC,
                params=params,
                headers=request_headers,
                data={
                    "at": self.access_token or "",  # Guest sessions have no SNlM0e token
                    "f.req": json.dumps([[payload.serialize() for payload in payloads]]).decode(
                        "utf-8"
                    ),
                },
                **kwargs,
            )

            if self.verbose:
                logger.debug(
                    f"HTTP Request: POST {Endpoint.BATCH_EXEC} [{response.status_code}] (HTTP/{format_http_version(response.http_version)})"
                )
        except ReadTimeout:
            raise TimeoutError(
                "The request timed out while waiting for Gemini to respond. This often happens with very long prompts "
                "or complex file analysis. Try increasing the 'timeout' value when initializing GeminiClient."
            ) from None

        if response.status_code != 200:
            if close_on_error:
                await self.close()
            raise APIError(f"Batch execution failed with status code {response.status_code}")

        return response

    def start_chat(self, **kwargs) -> "ChatSession":
        """Returns a `ChatSession` object attached to this client.

        Parameters
        ----------
        kwargs: `dict`, optional
            Additional arguments which will be passed to the chat session.
            Refer to `gemini_webapi.ChatSession` for more information.

        Returns
        -------
        :class:`ChatSession`
            Empty chat session object for retrieving conversation history.

        """
        return ChatSession(geminiclient=self, **kwargs)


class ChatSession:
    """Chat data to retrieve conversation history. Only if all 3 ids are provided will the conversation history be retrieved.

    Parameters
    ----------
    geminiclient: `GeminiClient`
        Async requests client interface for gemini.google.com.
    metadata: `list[str]`, optional
        List of chat metadata `[cid, rid, rcid]`, can be shorter than 3 elements, like `[cid, rid]` or `[cid]` only.
    cid: `str`, optional
        Chat ID, if provided together with metadata, will override the first value in it.
    rid: `str`, optional
        Reply ID, if provided together with metadata, will override the second value in it.
    rcid: `str`, optional
        Reply candidate ID, if provided together with metadata, will override the third value in it.
    model: `AvailableModel | str | dict`, optional
        Specify the model to use for generation. Pass a model name, alias or id string, or an
        `gemini_webapi.types.AvailableModel` from `list_models()`. Omit it to let Google use the
        account's default model. The `gemini_webapi.constants.Model` enum is deprecated and still
        accepted, with a warning.
    gem: `Gem | str`, optional
        Specify a gem to use as system prompt for the chat session.
        Pass either a `gemini_webapi.types.Gem` object or a gem id string.

    """

    __slots__ = [
        "__metadata",
        "gem",
        "geminiclient",
        "last_output",
        "model",
    ]

    def __init__(
        self,
        geminiclient: GeminiClient,
        metadata: list[str | None] | None = None,
        cid: str = "",  # chat id
        rid: str = "",  # reply id
        rcid: str = "",  # reply candidate id
        model: AvailableModel | Model | str | dict | None = None,
        gem: Gem | str | None = None,
    ):
        self.__metadata: list[Any] = DEFAULT_METADATA.copy()
        self.geminiclient: GeminiClient = geminiclient
        self.last_output: ModelOutput | None = None
        self.model: AvailableModel | Model | str | dict | None = model
        self.gem: Gem | str | None = gem

        if metadata:
            self.metadata = metadata
        if cid:
            self.cid = cid
        if rid:
            self.rid = rid
        if rcid:
            self.rcid = rcid

    def __str__(self):
        return f"ChatSession(cid={self.cid!r}, rid={self.rid!r}, rcid={self.rcid!r})"

    __repr__ = __str__

    def __setattr__(self, name: str, value: Any) -> None:
        super().__setattr__(name, value)
        # update conversation history when last output is updated
        if name == "last_output" and isinstance(value, ModelOutput):
            self.metadata = value.metadata
            self.rcid = value.rcid

    async def send_message(
        self,
        prompt: str,
        files: list[str | Path | bytes | io.BytesIO] | None = None,
        temporary: bool = False,
        deep_research: bool = False,
        extended_thinking: bool = False,
        **kwargs,
    ) -> ModelOutput:
        """Generates contents with prompt.
        Use as a shortcut for `GeminiClient.generate_content(prompt, files, self)`.

        Parameters
        ----------
        prompt: `str`
            Text prompt provided by user.
        files: `list[str | Path | bytes | io.BytesIO]`, optional
            List of file paths or byte streams to be attached.
        temporary: `bool`, optional
            If set to `True`, the ongoing conversation will not show up in Gemini history.
            Switching temporary mode within a chat session will clear the previous context
            and create a new chat session under the hood.
        deep_research: `bool`, optional
            If set to `True`, will enable deep research mode and start creating a deep research plan.
        extended_thinking: `bool`, optional
            If set to `True`, will enable extended thinking mode, default to standard.
        kwargs: `dict`, optional
            Additional arguments which will be passed to the post request.
            Refer to `curl_cffi.requests.AsyncSession.request` for more information.

        Returns
        -------
        :class:`ModelOutput`
            Output data from gemini.google.com.

        Raises
        ------
        `AssertionError`
            If prompt is empty.
        `gemini_webapi.TimeoutError`
            If request timed out.
        `gemini_webapi.GeminiError`
            If no reply candidate found in response.
        `gemini_webapi.APIError`
            - If request failed with status code other than 200.
            - If response structure is invalid and failed to parse.

        """
        return await self.geminiclient.generate_content(
            prompt=prompt,
            files=files,
            model=self.model,
            gem=self.gem,
            chat=self,
            temporary=temporary,
            deep_research=deep_research,
            extended_thinking=extended_thinking,
            **kwargs,
        )

    async def send_message_stream(
        self,
        prompt: str,
        files: list[str | Path | bytes | io.BytesIO] | None = None,
        temporary: bool = False,
        deep_research: bool = False,
        extended_thinking: bool = False,
        **kwargs,
    ) -> AsyncGenerator[ModelOutput, None]:
        """Generates contents with prompt in streaming mode within this chat session.

        This is a shortcut for `GeminiClient.generate_content_stream(prompt, files, self)`.
        The session's metadata and conversation history are automatically managed.

        Parameters
        ----------
        prompt: `str`
            Text prompt provided by user.
        files: `list[str | Path | bytes | io.BytesIO]`, optional
            List of file paths or byte streams to be attached.
        temporary: `bool`, optional
            If set to `True`, the ongoing conversation will not show up in Gemini history.
            Switching temporary mode within a chat session will clear the previous context
            and create a new chat session under the hood.
        deep_research: `bool`, optional
            If set to `True`, will enable deep research mode and start creating a deep research plan.
        extended_thinking: `bool`, optional
            If set to `True`, will enable extended thinking mode, default to standard.
        kwargs: `dict`, optional
            Additional arguments passed to the streaming request.

        Yields
        ------
        :class:`ModelOutput`
            Partial output data containing text deltas.

        """
        async for output in self.geminiclient.generate_content_stream(
            prompt=prompt,
            files=files,
            model=self.model,
            gem=self.gem,
            chat=self,
            temporary=temporary,
            deep_research=deep_research,
            extended_thinking=extended_thinking,
            **kwargs,
        ):
            yield output

    def choose_candidate(self, index: int) -> ModelOutput:
        """Choose a candidate from the last `ModelOutput` to control the ongoing conversation flow.

        Parameters
        ----------
        index: `int`
            Index of the candidate to choose, starting from 0.

        Returns
        -------
        :class:`ModelOutput`
            Output data of the chosen candidate.

        Raises
        ------
        `ValueError`
            If no previous output data found in this chat session, or if index exceeds the number of candidates in last model output.

        """
        if not self.last_output:
            raise ValueError("No previous output data found in this chat session.")

        if index >= len(self.last_output.candidates):
            raise ValueError(
                f"Index {index} exceeds the number of candidates in last model output."
            )

        self.last_output.chosen = index
        self.rcid = self.last_output.rcid
        return self.last_output

    async def read_history(self, limit: int = 10) -> ChatHistory | None:
        """Fetch the conversation history for this session.

        Parameters
        ----------
        limit: `int`, optional
            The maximum number of turns to fetch, by default 10.

        Returns
        -------
        :class:`ChatHistory` | None
            The conversation history, or None if reading failed or cid is missing.

        """
        if not self.cid:
            return None

        return await self.geminiclient.read_chat(self.cid, limit=limit)

    @property
    def metadata(self):
        return self.__metadata

    @metadata.setter
    def metadata(self, value: Sequence[str | None]):
        if not isinstance(value, list):
            return

        # Update only non-None elements to preserve existing CID/RID/RCID/Context
        for i, val in enumerate(value):
            if i < 10 and val is not None:
                self.__metadata[i] = val

    @property
    def cid(self):
        return self.__metadata[0]

    @cid.setter
    def cid(self, value: str):
        self.__metadata[0] = value

    @property
    def rid(self):
        return self.__metadata[1]

    @rid.setter
    def rid(self, value: str):
        self.__metadata[1] = value

    @property
    def rcid(self):
        return self.__metadata[2]

    @rcid.setter
    def rcid(self, value: str):
        self.__metadata[2] = value
